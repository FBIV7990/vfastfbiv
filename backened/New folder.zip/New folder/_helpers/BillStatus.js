module.exports={
    UNPAID: 'UNPAID',
    PAID: 'PAID'
}