module.exports={
    VERIFIED: 'VERIFIED',
    PENDING: 'PENDING',
    BLOCKED:  'BLOCKED',
    REGISTERED:  'REGISTERED'
}