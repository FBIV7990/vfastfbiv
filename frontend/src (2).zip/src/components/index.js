export * from './footer';
export * from './header';
export * from './slider';
export * from './body';
export * from './scrolltotop';
// export * from './services';
export * from './PrivateRoute';
export * from './SideMenu'
export * from './TextBox'
export * from './SelectBox'
export * from './TextArea'
export * from './NumberBox'