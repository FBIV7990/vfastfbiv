export const USER_KEY = "fsdfnklafklkjwekljfewkllwejfknfnasdf";
//export const apiUrl="http://localhost:4001";
export const apiUrl="https://www.vfast.co.in/api";