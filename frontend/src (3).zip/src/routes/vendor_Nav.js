

export default {
  items: [
    {
      name: "Home",
      url: "/",
      icon: "icon-speedometer",
    },  
    {
      name: "Verifications",
      url: "/verifications",
      icon: "icon-puzzle",
    },  
    {
      name: "Reports",
      icon: "icon-puzzle",
      url: "/reports"     
    }
  ],
};
