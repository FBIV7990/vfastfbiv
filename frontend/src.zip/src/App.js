import React from 'react';
import logo from './logo.svg';

import {Wrapper} from './container';


class App extends React.Component{

  render(){
    return( 
<>
<Wrapper/>
</>
     );
  }
}

export default App;
